﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_Connect4
{
    public partial class Form1 : Form
    {
        //fields
        BoardChecker bc = new BoardChecker();
        bool turn = true;
        int xWins = 0, oWins = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(1);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(1, "X");
                turn = false;
                if (r == 0)
                {
                    button12.Image = bmp;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp;
                    button7.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(1, "O");
                turn = true;
                if (r == 0)
                {
                    button12.Image = bmp2;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp2;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp2;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp2;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp2;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp2;
                    button7.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(0);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(0, "X");
                turn = false;
                if (r == 0)
                {
                    button6.Image = bmp;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp;
                    button1.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(0, "O");
                turn = true;
                if (r == 0)
                {
                    button6.Image = bmp2;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp2;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp2;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp2;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp2;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp2;
                    button1.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(0);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(0, "X");
                turn = false;
                if (r == 0)
                {
                    button6.Image = bmp;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp;
                    button1.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(0, "O");
                turn = true;
                if (r == 0)
                {
                    button6.Image = bmp2;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp2;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp2;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp2;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp2;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp2;
                    button1.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(0);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(0, "X");
                turn = false;
                if (r == 0)
                {
                    button6.Image = bmp;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp;
                    button1.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(0, "O");
                turn = true;
                if (r == 0)
                {
                    button6.Image = bmp2;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp2;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp2;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp2;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp2;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp2;
                    button1.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(0);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(0, "X");
                turn = false;
                if (r == 0)
                {
                    button6.Image = bmp;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp;
                    button1.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(0, "O");
                turn = true;
                if (r == 0)
                {
                    button6.Image = bmp2;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp2;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp2;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp2;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp2;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp2;
                    button1.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(0);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(0, "X");
                turn = false;
                if (r == 0)
                {
                    button6.Image = bmp;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp;
                    button1.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(0, "O");
                turn = true;
                if (r == 0)
                {
                    button6.Image = bmp2;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp2;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp2;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp2;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp2;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp2;
                    button1.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(1);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(1, "X");
                turn = false;
                if (r == 0)
                {
                    button12.Image = bmp;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp;
                    button7.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(1, "O");
                turn = true;
                if (r == 0)
                {
                    button12.Image = bmp2;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp2;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp2;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp2;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp2;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp2;
                    button7.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(1);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(1, "X");
                turn = false;
                if (r == 0)
                {
                    button12.Image = bmp;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp;
                    button7.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(1, "O");
                turn = true;
                if (r == 0)
                {
                    button12.Image = bmp2;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp2;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp2;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp2;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp2;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp2;
                    button7.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(1);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(1, "X");
                turn = false;
                if (r == 0)
                {
                    button12.Image = bmp;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp;
                    button7.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(1, "O");
                turn = true;
                if (r == 0)
                {
                    button12.Image = bmp2;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp2;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp2;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp2;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp2;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp2;
                    button7.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(1);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(1, "X");
                turn = false;
                if (r == 0)
                {
                    button12.Image = bmp;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp;
                    button7.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(1, "O");
                turn = true;
                if (r == 0)
                {
                    button12.Image = bmp2;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp2;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp2;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp2;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp2;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp2;
                    button7.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(1);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(1, "X");
                turn = false;
                if (r == 0)
                {
                    button12.Image = bmp;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp;
                    button7.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(1, "O");
                turn = true;
                if (r == 0)
                {
                    button12.Image = bmp2;
                    button12.Update();
                }
                else if (r == 1)
                {
                    button11.Image = bmp2;
                    button11.Update();
                }
                else if (r == 2)
                {
                    button10.Image = bmp2;
                    button10.Update();
                }
                else if (r == 3)
                {
                    button9.Image = bmp2;
                    button9.Update();
                }
                else if (r == 4)
                {
                    button8.Image = bmp2;
                    button8.Update();
                }
                else if (r == 5)
                {
                    button7.Image = bmp2;
                    button7.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(2);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(2, "X");
                turn = false;
                if (r == 0)
                {
                    button18.Image = bmp;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp;
                    button13.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(2, "O");
                turn = true;
                if (r == 0)
                {
                    button18.Image = bmp2;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp2;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp2;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp2;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp2;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp2;
                    button13.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(2);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(2, "X");
                turn = false;
                if (r == 0)
                {
                    button18.Image = bmp;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp;
                    button13.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(2, "O");
                turn = true;
                if (r == 0)
                {
                    button18.Image = bmp2;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp2;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp2;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp2;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp2;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp2;
                    button13.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(2);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(2, "X");
                turn = false;
                if (r == 0)
                {
                    button18.Image = bmp;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp;
                    button13.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(2, "O");
                turn = true;
                if (r == 0)
                {
                    button18.Image = bmp2;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp2;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp2;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp2;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp2;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp2;
                    button13.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(2);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(2, "X");
                turn = false;
                if (r == 0)
                {
                    button18.Image = bmp;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp;
                    button13.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(2, "O");
                turn = true;
                if (r == 0)
                {
                    button18.Image = bmp2;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp2;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp2;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp2;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp2;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp2;
                    button13.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(2);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(2, "X");
                turn = false;
                if (r == 0)
                {
                    button18.Image = bmp;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp;
                    button13.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(2, "O");
                turn = true;
                if (r == 0)
                {
                    button18.Image = bmp2;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp2;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp2;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp2;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp2;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp2;
                    button13.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(2);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(2, "X");
                turn = false;
                if (r == 0)
                {
                    button18.Image = bmp;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp;
                    button13.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(2, "O");
                turn = true;
                if (r == 0)
                {
                    button18.Image = bmp2;
                    button18.Update();
                }
                else if (r == 1)
                {
                    button17.Image = bmp2;
                    button17.Update();
                }
                else if (r == 2)
                {
                    button16.Image = bmp2;
                    button16.Update();
                }
                else if (r == 3)
                {
                    button15.Image = bmp2;
                    button15.Update();
                }
                else if (r == 4)
                {
                    button14.Image = bmp2;
                    button14.Update();
                }
                else if (r == 5)
                {
                    button13.Image = bmp2;
                    button13.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(3);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(3, "X");
                turn = false;
                if (r == 0)
                {
                    button24.Image = bmp;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp;
                    button19.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(3, "O");
                turn = true;
                if (r == 0)
                {
                    button24.Image = bmp2;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp2;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp2;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp2;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp2;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp2;
                    button19.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(3);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(3, "X");
                turn = false;
                if (r == 0)
                {
                    button24.Image = bmp;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp;
                    button19.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(3, "O");
                turn = true;
                if (r == 0)
                {
                    button24.Image = bmp2;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp2;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp2;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp2;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp2;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp2;
                    button19.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(3);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(3, "X");
                turn = false;
                if (r == 0)
                {
                    button24.Image = bmp;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp;
                    button19.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(3, "O");
                turn = true;
                if (r == 0)
                {
                    button24.Image = bmp2;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp2;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp2;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp2;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp2;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp2;
                    button19.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(3);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(3, "X");
                turn = false;
                if (r == 0)
                {
                    button24.Image = bmp;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp;
                    button19.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(3, "O");
                turn = true;
                if (r == 0)
                {
                    button24.Image = bmp2;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp2;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp2;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp2;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp2;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp2;
                    button19.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(3);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(3, "X");
                turn = false;
                if (r == 0)
                {
                    button24.Image = bmp;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp;
                    button19.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(3, "O");
                turn = true;
                if (r == 0)
                {
                    button24.Image = bmp2;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp2;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp2;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp2;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp2;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp2;
                    button19.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(3);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(3, "X");
                turn = false;
                if (r == 0)
                {
                    button24.Image = bmp;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp;
                    button19.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(3, "O");
                turn = true;
                if (r == 0)
                {
                    button24.Image = bmp2;
                    button24.Update();
                }
                else if (r == 1)
                {
                    button23.Image = bmp2;
                    button23.Update();
                }
                else if (r == 2)
                {
                    button22.Image = bmp2;
                    button22.Update();
                }
                else if (r == 3)
                {
                    button21.Image = bmp2;
                    button21.Update();
                }
                else if (r == 4)
                {
                    button20.Image = bmp2;
                    button20.Update();
                }
                else if (r == 5)
                {
                    button19.Image = bmp2;
                    button19.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(4);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(4, "X");
                turn = false;
                if (r == 0)
                {
                    button30.Image = bmp;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp;
                    button25.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(4, "O");
                turn = true;
                if (r == 0)
                {
                    button30.Image = bmp2;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp2;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp2;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp2;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp2;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp2;
                    button25.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button26_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(4);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(4, "X");
                turn = false;
                if (r == 0)
                {
                    button30.Image = bmp;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp;
                    button25.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(4, "O");
                turn = true;
                if (r == 0)
                {
                    button30.Image = bmp2;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp2;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp2;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp2;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp2;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp2;
                    button25.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button27_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(4);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(4, "X");
                turn = false;
                if (r == 0)
                {
                    button30.Image = bmp;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp;
                    button25.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(4, "O");
                turn = true;
                if (r == 0)
                {
                    button30.Image = bmp2;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp2;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp2;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp2;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp2;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp2;
                    button25.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button28_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(4);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(4, "X");
                turn = false;
                if (r == 0)
                {
                    button30.Image = bmp;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp;
                    button25.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(4, "O");
                turn = true;
                if (r == 0)
                {
                    button30.Image = bmp2;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp2;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp2;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp2;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp2;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp2;
                    button25.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button29_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(4);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(4, "X");
                turn = false;
                if (r == 0)
                {
                    button30.Image = bmp;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp;
                    button25.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(4, "O");
                turn = true;
                if (r == 0)
                {
                    button30.Image = bmp2;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp2;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp2;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp2;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp2;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp2;
                    button25.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button30_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(4);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(4, "X");
                turn = false;
                if (r == 0)
                {
                    button30.Image = bmp;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp;
                    button25.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(4, "O");
                turn = true;
                if (r == 0)
                {
                    button30.Image = bmp2;
                    button30.Update();
                }
                else if (r == 1)
                {
                    button29.Image = bmp2;
                    button29.Update();
                }
                else if (r == 2)
                {
                    button28.Image = bmp2;
                    button28.Update();
                }
                else if (r == 3)
                {
                    button27.Image = bmp2;
                    button27.Update();
                }
                else if (r == 4)
                {
                    button26.Image = bmp2;
                    button26.Update();
                }
                else if (r == 5)
                {
                    button25.Image = bmp2;
                    button25.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button31_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(5);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(5, "X");
                turn = false;
                if (r == 0)
                {
                    button36.Image = bmp;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp;
                    button31.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(5, "O");
                turn = true;
                if (r == 0)
                {
                    button36.Image = bmp2;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp2;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp2;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp2;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp2;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp2;
                    button31.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button32_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(5);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(5, "X");
                turn = false;
                if (r == 0)
                {
                    button36.Image = bmp;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp;
                    button31.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(5, "O");
                turn = true;
                if (r == 0)
                {
                    button36.Image = bmp2;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp2;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp2;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp2;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp2;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp2;
                    button31.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button33_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(5);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(5, "X");
                turn = false;
                if (r == 0)
                {
                    button36.Image = bmp;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp;
                    button31.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(5, "O");
                turn = true;
                if (r == 0)
                {
                    button36.Image = bmp2;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp2;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp2;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp2;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp2;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp2;
                    button31.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button34_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(5);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(5, "X");
                turn = false;
                if (r == 0)
                {
                    button36.Image = bmp;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp;
                    button31.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(5, "O");
                turn = true;
                if (r == 0)
                {
                    button36.Image = bmp2;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp2;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp2;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp2;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp2;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp2;
                    button31.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button35_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(5);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(5, "X");
                turn = false;
                if (r == 0)
                {
                    button36.Image = bmp;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp;
                    button31.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(5, "O");
                turn = true;
                if (r == 0)
                {
                    button36.Image = bmp2;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp2;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp2;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp2;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp2;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp2;
                    button31.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button36_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(5);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(5, "X");
                turn = false;
                if (r == 0)
                {
                    button36.Image = bmp;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp;
                    button31.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(5, "O");
                turn = true;
                if (r == 0)
                {
                    button36.Image = bmp2;
                    button36.Update();
                }
                else if (r == 1)
                {
                    button35.Image = bmp2;
                    button35.Update();
                }
                else if (r == 2)
                {
                    button34.Image = bmp2;
                    button34.Update();
                }
                else if (r == 3)
                {
                    button33.Image = bmp2;
                    button33.Update();
                }
                else if (r == 4)
                {
                    button32.Image = bmp2;
                    button32.Update();
                }
                else if (r == 5)
                {
                    button31.Image = bmp2;
                    button31.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button37_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(6);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(6, "X");
                turn = false;
                if (r == 0)
                {
                    button42.Image = bmp;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp;
                    button37.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(6, "O");
                turn = true;
                if (r == 0)
                {
                    button42.Image = bmp2;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp2;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp2;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp2;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp2;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp2;
                    button37.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button38_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(6);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(6, "X");
                turn = false;
                if (r == 0)
                {
                    button42.Image = bmp;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp;
                    button37.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(6, "O");
                turn = true;
                if (r == 0)
                {
                    button42.Image = bmp2;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp2;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp2;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp2;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp2;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp2;
                    button37.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button39_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(6);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(6, "X");
                turn = false;
                if (r == 0)
                {
                    button42.Image = bmp;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp;
                    button37.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(6, "O");
                turn = true;
                if (r == 0)
                {
                    button42.Image = bmp2;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp2;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp2;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp2;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp2;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp2;
                    button37.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button40_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(6);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(6, "X");
                turn = false;
                if (r == 0)
                {
                    button42.Image = bmp;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp;
                    button37.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(6, "O");
                turn = true;
                if (r == 0)
                {
                    button42.Image = bmp2;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp2;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp2;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp2;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp2;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp2;
                    button37.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button41_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(6);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(6, "X");
                turn = false;
                if (r == 0)
                {
                    button42.Image = bmp;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp;
                    button37.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(6, "O");
                turn = true;
                if (r == 0)
                {
                    button42.Image = bmp2;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp2;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp2;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp2;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp2;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp2;
                    button37.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void button42_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(6);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(6, "X");
                turn = false;
                if (r == 0)
                {
                    button42.Image = bmp;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp;
                    button37.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(6, "O");
                turn = true;
                if (r == 0)
                {
                    button42.Image = bmp2;
                    button42.Update();
                }
                else if (r == 1)
                {
                    button41.Image = bmp2;
                    button41.Update();
                }
                else if (r == 2)
                {
                    button40.Image = bmp2;
                    button40.Update();
                }
                else if (r == 3)
                {
                    button39.Image = bmp2;
                    button39.Update();
                }
                else if (r == 4)
                {
                    button38.Image = bmp2;
                    button38.Update();
                }
                else if (r == 5)
                {
                    button37.Image = bmp2;
                    button37.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }
        }

        private void playButton_Click(object sender, EventArgs e)
        {
            //resetting buttons
            button1.Image = null;
            button2.Image = null;
            button3.Image = null;
            button4.Image = null;
            button5.Image = null;
            button6.Image = null;
            button7.Image = null;
            button8.Image = null;
            button9.Image = null;
            button10.Image = null;
            button11.Image = null;
            button12.Image = null;
            button13.Image = null;
            button14.Image = null;
            button15.Image = null;
            button16.Image = null;
            button17.Image = null;
            button18.Image = null;
            button19.Image = null;
            button20.Image = null;
            button21.Image = null;
            button22.Image = null;
            button23.Image = null;
            button24.Image = null;
            button25.Image = null;
            button26.Image = null;
            button27.Image = null;
            button28.Image = null;
            button29.Image = null;
            button30.Image = null;
            button31.Image = null;
            button32.Image = null;
            button33.Image = null;
            button34.Image = null;
            button35.Image = null;
            button36.Image = null;
            button37.Image = null;
            button38.Image = null;
            button39.Image = null;
            button40.Image = null;
            button41.Image = null;
            button42.Image = null;

            //resetting text
            turn = true;
            turnBox.Text = "X";
            winBox.Text = "";
            bc.reset();
        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            //resetting buttons
            button1.Image = null;
            button2.Image = null;
            button3.Image = null;
            button4.Image = null;
            button5.Image = null;
            button6.Image = null;
            button7.Image = null;
            button8.Image = null;
            button9.Image = null;
            button10.Image = null;
            button11.Image = null;
            button12.Image = null;
            button13.Image = null;
            button14.Image = null;
            button15.Image = null;
            button16.Image = null;
            button17.Image = null;
            button18.Image = null;
            button19.Image = null;
            button20.Image = null;
            button21.Image = null;
            button22.Image = null;
            button23.Image = null;
            button24.Image = null;
            button25.Image = null;
            button26.Image = null;
            button27.Image = null;
            button28.Image = null;
            button29.Image = null;
            button30.Image = null;
            button31.Image = null;
            button32.Image = null;
            button33.Image = null;
            button34.Image = null;
            button35.Image = null;
            button36.Image = null;
            button37.Image = null;
            button38.Image = null;
            button39.Image = null;
            button40.Image = null;
            button41.Image = null;
            button42.Image = null;

            //resetting text and records
            turn = true;
            turnBox.Text = "X";
            winBox.Text = "";
            recordLabel.Text = "Records:";
            xWins = 0;
            oWins = 0;
            bc.reset();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //fields
            int r = bc.getRow(0);

            //creating bitmaps
            Bitmap bmp = new Bitmap(Properties.Resources.logo, button1.Width, button1.Height);
            Bitmap bmp2 = new Bitmap(Properties.Resources.cat, button1.Width, button1.Height);

            //accumulating player entry into correct spot
            if (turn) //X player's turn
            {
                bc.Accumulate(0, "X");
                turn = false;
                if (r == 0)
                {
                    button6.Image = bmp;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp;
                    button1.Update();
                }

                //checking to see if X won
                if (bc.Winner())
                {
                    xWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: X";
                }
                //updating turn box
                turnBox.Text = "O";

            }
            else //O player's turn
            {
                bc.Accumulate(0, "O");
                turn = true;
                if (r == 0)
                {
                    button6.Image = bmp2;
                    button6.Update();
                }
                else if (r == 1)
                {
                    button5.Image = bmp2;
                    button5.Update();
                }
                else if (r == 2)
                {
                    button4.Image = bmp2;
                    button4.Update();
                }
                else if (r == 3)
                {
                    button3.Image = bmp2;
                    button3.Update();
                }
                else if (r == 4)
                {
                    button2.Image = bmp2;
                    button2.Update();
                }
                else if (r == 5)
                {
                    button1.Image = bmp2;
                    button1.Update();
                }

                //checking to see if O won
                if (bc.Winner())
                {
                    oWins++;
                    recordLabel.Text = "Records:" + Environment.NewLine + "X wins: " + xWins +
                        Environment.NewLine + "O wins: " + oWins;
                    winBox.Text = "Winner: O";
                }

                //updating turn box
                turnBox.Text = "X";
            }

        }
    }
}
