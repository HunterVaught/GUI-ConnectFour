﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI_Connect4
{
    class BoardChecker : IWinner
    {
        //fields
        string[,] board = new string[7, 6];
        int[] c = { 0, 0, 0, 0, 0, 0, 0 };

        //methods
        public void Accumulate(int i, string s)
        {
            try
            {
                board[i, c[i]] = s;
                c[i]++;
            }
            catch
            {
                
            }
        }

        //resets arrays
        public void reset()
        {
            for(int i = 0; i < 7; i++)
            {
                for(int j = 0; j < 6; j++)
                {
                    board[i, j] = "";
                }
                c[i] = 0;
            }
        }

        //return what row in specified column the stack is up to
        public int getRow(int i)
        {
            return c[i];
        }

        //find winner in column c going up starting from (r,c)
        public bool Straightup(int r, int c)
        {
            if (board[c, r] == board[c, r + 1] && board[c, r + 1] == board[c, r + 2] &&
                board[c, r + 2] == board[c, r + 3])
                return true;
            return false;
        }

        //find winner in column c going down starting from (r,c)
        public bool Straightdown(int r, int c)
        {
            try
            {
                if (board[c, r] == board[c, r - 1] && board[c, r - 1] == board[c, r - 2] &&
                    board[c, r - 2] == board[c, r - 3])
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        //find a winner in row r going left starting from (r,c)
        public bool Left(int r, int c)
        {
            try
            {
                if (board[c, r] == board[c - 1, r] && board[c - 1, r] == board[c - 2, r] &&
                    board[c - 2, r] == board[c - 3, r])
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        //find a winner in row r going right starting from (r,c)
        public bool Right(int r, int c)
        {
            try
            {
                if (board[c, r] == board[c + 1, r] && board[c + 1, r] == board[c + 2, r] &&
                    board[c + 2, r] == board[c + 3, r])
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        //find a winner in diagonal left going up starting from (r,c)
        public bool Diagleftup(int r, int c)
        {
            try
            {
                if (board[c, r] == board[c - 1, r + 1] && board[c - 1, r + 1] == board[c - 2, r + 2] &&
                    board[c - 2, r + 2] == board[c - 3, r + 3])
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        //find a winner in diagonal right going down starting from(r, c)
        public bool Diagrightdown(int r, int c)
        {
            try
            {
                if (board[c, r] == board[c + 1, r - 1] && board[c + 1, r - 1] == board[c + 2, r - 2] &&
                    board[c + 2, r - 2] == board[c + 3, r - 3])
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        //find a winner in diagonal left going down starting from(r, c)
        public bool Diagleftdown(int r, int c)
        {
            try
            {
                if (board[c, r] == board[c - 1, r - 1] && board[c - 1, r - 1] == board[c - 2, r - 2] &&
                    board[c - 2, r - 2] == board[c - 3, r - 3])
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        //find a winner in diagonal right going up starting from(r, c)
        public bool Diagrightup(int r, int c)
        {
            try
            {
                if (board[c, r] == board[c + 1, r + 1] && board[c + 1, r + 1] == board[c + 2, r + 2] &&
                    board[c + 2, r + 2] == board[c + 3, r + 3])
                    return true;
                return false;
            }
            catch
            {
                return false;
            }
        }

        //return true if there is winner this function should use the previous one
        public bool Winner()
        {
            if (Straightdown(c[0]-1, 0) || Right(c[0]-1, 0) || Diagrightdown(c[0] - 1, 0) || Diagrightup(c[0] - 1, 0) ||
                Straightdown(c[1] - 1, 1) || Right(c[1] - 1, 1) || Diagrightdown(c[1] - 1, 1) ||
                Diagrightup(c[1] - 1, 1) || Straightdown(c[2] - 1, 2) || Right(c[2] - 1, 2) ||
                Diagrightdown(c[2] - 1, 2) || Diagrightup(c[2] - 1, 2) || Straightdown(c[3] - 1, 3) ||
                Right(c[3] - 1, 3) || Left(c[3] - 1, 3) || Diagrightdown(c[3] - 1, 3) || Diagrightup(c[3] - 1, 3) ||
                Diagleftup(c[3] - 1, 3) || Diagleftdown(c[3] - 1, 3) || Straightdown(c[4] - 1, 4) ||
                Left(c[4] - 1, 4) || Diagleftdown(c[4] - 1, 4) || Diagleftup(c[4] - 1, 4) || Straightdown(c[5] - 1, 5) ||
                Left(c[5] - 1, 5) || Diagleftdown(c[5] - 1, 5) || Diagleftup(c[5] - 1, 5) || Straightdown(c[6] - 1, 6) ||
                Left(c[6] - 1, 6) || Diagleftdown(c[6] - 1, 6) || Diagleftup(c[6] - 1, 6))
                return true;
            return false;
        }
    }
}
